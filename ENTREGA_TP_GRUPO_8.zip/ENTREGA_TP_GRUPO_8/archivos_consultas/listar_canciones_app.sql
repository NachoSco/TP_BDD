SELECT * FROM aplicacion_musica.canciones;
