INSERT INTO aplicacion_musica.canciones 
(nombre_cancion,duracion_cancion,genero_cancion)
VALUES ('Prófugos', 271, 'rock');
