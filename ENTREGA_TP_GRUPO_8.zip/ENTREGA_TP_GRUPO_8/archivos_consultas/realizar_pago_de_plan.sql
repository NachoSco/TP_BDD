-- Asumimos que existe el Plan De subscripcion Premium
INSERT INTO aplicacion_musica.pagos (nombre_usuario, nombre_plan, forma_pago) VALUES
('vale_rock', 'Premium', 'credito');
