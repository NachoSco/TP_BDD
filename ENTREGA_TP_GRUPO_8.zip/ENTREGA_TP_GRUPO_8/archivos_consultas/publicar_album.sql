INSERT INTO aplicacion_musica.albumes 
(nombre_artista,nombre_album,fecha_lanzamiento)
VALUES ('Soda Stereo','Signos','1986-11-10');
