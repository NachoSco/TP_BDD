UPDATE aplicacion_musica.canciones 
SET nombre_cancion = 'New Divide'
WHERE nombre_cancion = 'Tan Solo';
