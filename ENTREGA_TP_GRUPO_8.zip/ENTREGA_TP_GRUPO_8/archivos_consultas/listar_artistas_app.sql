SELECT * FROM aplicacion_musica.artistas;
