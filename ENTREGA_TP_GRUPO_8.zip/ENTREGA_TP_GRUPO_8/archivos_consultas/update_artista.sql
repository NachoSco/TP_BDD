UPDATE aplicacion_musica.artistas 
SET nombre_artista = 'Linkin Park'
WHERE nombre_artista = 'Soda Stereo';
