SELECT *
FROM aplicacion_musica.albumes 
ORDER BY nombre_artista;
--OPCION 2
--SELECT nombre_artista,nombre_album,fecha_lanzamiento FROM aplicacion_musica.albumes GROUP BY nombre_artista,nombre_album,fecha_lanzamiento;
--OPCION 3
--SELECT * FROM aplicacion_musica.albumes;
