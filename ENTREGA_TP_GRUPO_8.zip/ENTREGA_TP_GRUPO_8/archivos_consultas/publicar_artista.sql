INSERT INTO aplicacion_musica.artistas 
(nombre_artista,tipo_artista,pais)
VALUES ('Intoxicados','banda','Argentina');
