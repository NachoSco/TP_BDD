UPDATE aplicacion_musica.albumes
SET fecha_lanzamiento = '2000-02-10'
WHERE  fecha_lanzamiento = '1990-09-17';
